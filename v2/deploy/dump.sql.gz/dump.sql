-- MySQL dump 10.13  Distrib 5.7.35, for Linux (x86_64)
--
-- Host: localhost    Database: roki
-- ------------------------------------------------------
-- Server version	5.7.35-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Korisnici`
--

DROP TABLE IF EXISTS `Korisnici`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Korisnici` (
                             `id` int(11) NOT NULL AUTO_INCREMENT,
                             `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                             `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                             `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                             `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                             `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                             PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Korisnici`
--

LOCK TABLES `Korisnici` WRITE;
/*!40000 ALTER TABLE `Korisnici` DISABLE KEYS */;
INSERT INTO `Korisnici` VALUES (1,'a','a','roki','a','roki'),(2,'Milica','Jaric','roki','mici','roki'),(3,'milica','jaric','roki','mici','roki');
/*!40000 ALTER TABLE `Korisnici` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Roki`
--

DROP TABLE IF EXISTS `Roki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Roki` (
                        `Sifra robe` int(11) DEFAULT NULL,
                        `Naziv robe` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                        `Tip robe` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                        `Sezona` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                        `Nabavna cijena` int(11) DEFAULT NULL,
                        `Troskovi` int(11) DEFAULT NULL,
                        `Cijena` int(11) DEFAULT NULL,
                        `Z/M` tinyint(1) DEFAULT NULL,
                        `Proizvodjac` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                        `Zemlja porijekla` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Roki`
--

LOCK TABLES `Roki` WRITE;
/*!40000 ALTER TABLE `Roki` DISABLE KEYS */;
INSERT INTO `Roki` VALUES (1,'1','1','1',1,11,1,1,'1','1');
/*!40000 ALTER TABLE `Roki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kupci`
--

DROP TABLE IF EXISTS `kupci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kupci` (
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `ime` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `psw` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `telefon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `adresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `grad` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `napomene` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kupci`
--

LOCK TABLES `kupci` WRITE;
/*!40000 ALTER TABLE `kupci` DISABLE KEYS */;
/*!40000 ALTER TABLE `kupci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
                          `id` int(11) NOT NULL AUTO_INCREMENT,
                          `datum_orders` datetime DEFAULT CURRENT_TIMESTAMP,
                          `ukupno` float DEFAULT NULL,
                          PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'2021-05-26 13:01:34',56),(2,'2021-05-27 18:31:48',0),(3,'2021-05-27 18:32:02',85),(4,'2021-05-27 18:32:25',85),(5,'2021-05-27 18:39:02',85),(6,'2021-05-27 18:39:19',85),(7,'2021-05-27 18:51:09',85),(8,'2021-05-27 18:58:53',85),(9,'2021-05-27 18:58:53',85),(10,'2021-05-27 18:58:53',85),(11,'2021-05-27 18:58:53',85),(12,'2021-05-27 18:59:41',67),(13,'2021-05-27 18:59:41',67),(14,'2021-05-27 18:59:41',67),(15,'2021-05-27 18:59:41',67),(16,'2021-05-27 18:59:41',67),(17,'2021-05-27 18:59:41',67),(18,'2021-05-27 19:02:04',60),(19,'2021-05-27 22:54:08',106),(20,'2021-05-31 22:55:20',308),(21,'2021-06-01 00:46:43',27),(22,'2021-06-01 01:37:11',32),(23,'2021-06-01 01:37:20',0),(24,'2021-06-01 01:45:47',77),(25,'2021-06-01 01:47:08',0),(26,'2021-06-01 01:47:54',0),(27,'2021-06-01 01:48:12',0),(28,'2021-06-01 01:48:20',0),(29,'2021-06-01 01:48:48',0),(30,'2021-06-01 01:50:08',27),(31,'2021-06-01 01:54:51',52),(32,'2021-06-01 01:59:53',52),(33,'2021-06-06 15:34:50',281),(34,'2021-06-06 16:16:39',431),(35,'2021-06-06 16:16:42',431),(36,'2021-06-06 16:18:01',431),(37,'2021-06-06 16:24:16',431),(38,'2021-06-06 16:24:19',431),(39,'2021-06-06 16:24:22',431),(40,'2021-06-06 16:25:06',431),(41,'2021-06-06 16:25:10',431),(42,'2021-06-06 16:27:20',431),(43,'2021-06-06 16:28:09',731),(44,'2021-06-06 16:28:36',731),(45,'2021-06-06 16:29:00',731),(46,'2021-06-06 16:30:48',731),(47,'2021-06-06 16:30:52',731),(48,'2021-06-06 16:32:20',731),(49,'2021-06-06 16:34:01',731),(50,'2021-06-06 16:35:16',150),(51,'2021-06-08 13:53:26',201),(52,'2021-06-08 13:55:11',201),(53,'2021-06-08 13:55:42',201),(54,'2021-06-08 13:56:10',201),(55,'2021-06-08 13:59:12',201),(56,'2021-06-08 13:59:51',201),(57,'2021-06-08 14:00:07',201),(58,'2021-06-08 14:00:32',201),(59,'2021-06-08 21:16:51',0),(60,'2021-06-08 21:17:13',10);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_items`
--

DROP TABLE IF EXISTS `orders_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_items` (
                                `id` int(11) NOT NULL AUTO_INCREMENT,
                                `orders_id` int(11) DEFAULT NULL,
                                `produts_id` int(11) DEFAULT NULL,
                                `kolicina` int(11) DEFAULT NULL,
                                `cijena` float DEFAULT NULL,
                                `ukupno_items` int(11) DEFAULT NULL,
                                PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_items`
--

LOCK TABLES `orders_items` WRITE;
/*!40000 ALTER TABLE `orders_items` DISABLE KEYS */;
INSERT INTO `orders_items` VALUES (1,18,4,1,50,50),(2,18,8,1,5,5),(3,18,22,1,5,5),(4,19,4,2,50,100),(5,19,9,1,1,1),(6,19,22,1,5,5),(7,20,5,2,50,100),(8,20,6,4,50,200),(9,20,7,3,1,3),(10,20,8,1,5,5),(11,21,10,1,1,1),(12,21,24,1,25,25),(13,21,27,1,1,1),(14,22,10,1,1,1),(15,22,24,1,25,25),(16,22,27,1,1,1),(17,22,28,1,5,5),(18,24,10,1,1,1),(19,24,24,1,25,25),(20,24,27,1,1,1),(21,24,29,1,50,50),(22,30,10,1,1,1),(23,30,24,1,25,25),(24,30,27,1,1,1),(25,31,10,1,1,1),(26,31,24,2,25,50),(27,31,27,1,1,1),(28,32,10,1,1,1),(29,32,24,2,25,50),(30,32,27,1,1,1),(31,33,10,1,150,150),(32,33,24,1,25,25),(33,33,27,1,1,1),(34,33,28,1,5,5),(35,33,29,1,50,50),(36,33,30,1,50,50),(37,34,10,2,150,300),(38,34,24,1,25,25),(39,34,27,1,1,1),(40,34,28,1,5,5),(41,34,29,1,50,50),(42,34,30,1,50,50),(43,35,10,2,150,300),(44,35,24,1,25,25),(45,35,27,1,1,1),(46,35,28,1,5,5),(47,35,29,1,50,50),(48,35,30,1,50,50),(49,36,10,2,150,300),(50,36,24,1,25,25),(51,36,27,1,1,1),(52,36,28,1,5,5),(53,36,29,1,50,50),(54,36,30,1,50,50),(55,37,10,2,150,300),(56,37,24,1,25,25),(57,37,27,1,1,1),(58,37,28,1,5,5),(59,37,29,1,50,50),(60,37,30,1,50,50),(61,38,10,2,150,300),(62,38,24,1,25,25),(63,38,27,1,1,1),(64,38,28,1,5,5),(65,38,29,1,50,50),(66,38,30,1,50,50),(67,39,10,2,150,300),(68,39,24,1,25,25),(69,39,27,1,1,1),(70,39,28,1,5,5),(71,39,29,1,50,50),(72,39,30,1,50,50),(73,40,10,2,150,300),(74,40,24,1,25,25),(75,40,27,1,1,1),(76,40,28,1,5,5),(77,40,29,1,50,50),(78,40,30,1,50,50),(79,41,10,2,150,300),(80,41,24,1,25,25),(81,41,27,1,1,1),(82,41,28,1,5,5),(83,41,29,1,50,50),(84,41,30,1,50,50),(85,42,10,2,150,300),(86,42,24,1,25,25),(87,42,27,1,1,1),(88,42,28,1,5,5),(89,42,29,1,50,50),(90,42,30,1,50,50),(91,43,10,4,150,600),(92,43,24,1,25,25),(93,43,27,1,1,1),(94,43,28,1,5,5),(95,43,29,1,50,50),(96,43,30,1,50,50),(97,44,10,4,150,600),(98,44,24,1,25,25),(99,44,27,1,1,1),(100,44,28,1,5,5),(101,44,29,1,50,50),(102,44,30,1,50,50),(103,45,10,4,150,600),(104,45,24,1,25,25),(105,45,27,1,1,1),(106,45,28,1,5,5),(107,45,29,1,50,50),(108,45,30,1,50,50),(109,46,10,4,150,600),(110,46,24,1,25,25),(111,46,27,1,1,1),(112,46,28,1,5,5),(113,46,29,1,50,50),(114,46,30,1,50,50),(115,47,10,4,150,600),(116,47,24,1,25,25),(117,47,27,1,1,1),(118,47,28,1,5,5),(119,47,29,1,50,50),(120,47,30,1,50,50),(121,48,10,4,150,600),(122,49,10,4,150,600),(123,49,24,1,25,25),(124,49,27,1,1,1),(125,49,28,1,5,5),(126,49,29,1,50,50),(127,49,30,1,50,50),(128,50,10,1,150,150),(129,51,10,1,150,150),(130,51,27,1,1,1),(131,51,29,1,50,50),(132,52,10,1,150,150),(133,52,27,1,1,1),(134,52,29,1,50,50),(135,53,10,1,150,150),(136,53,27,1,1,1),(137,53,29,1,50,50),(138,54,10,1,150,150),(139,54,27,1,1,1),(140,54,29,1,50,50),(141,55,10,1,150,150),(142,55,27,1,1,1),(143,55,29,1,50,50),(144,56,10,1,150,150),(145,56,27,1,1,1),(146,56,29,1,50,50),(147,57,10,1,150,150),(148,57,27,1,1,1),(149,57,29,1,50,50),(150,58,10,1,150,150),(151,58,27,1,1,1),(152,58,29,1,50,50),(153,60,28,2,5,10);
/*!40000 ALTER TABLE `orders_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `ime_proizvoda` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                            `cijena` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                            `opis_proizvoda` text COLLATE utf8mb4_unicode_ci,
                            `slika` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                            `visitor_counter` int(11) DEFAULT '0',
                            `zalihe robe` int(11) DEFAULT NULL,
                            `new_column` int(11) DEFAULT NULL,
                            `kolicina` int(11) DEFAULT NULL,
                            PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (10,'Muska kosulja','150','Muska kosulja','/image/images.jpeg',13,NULL,NULL,100),(24,'Zenska kosulja','25','Zenska kosulja ','/image/images.jpeg',4,NULL,NULL,150),(27,'Zenske hlace','1','Zenske ljetne hlace.\nDostupne u vise boja','https://www.modnialmanah.com/wp-content/uploads/2018/03/hla%C4%8De-2.jpg',3,NULL,NULL,NULL),(28,'Sako','5','Muski sako','https://www.legend.rs/product_images/2021pl/3902_7990_05-1200x1600-teget-poslovni-sako.jpg',5,NULL,NULL,NULL),(29,'Muske hlace','50','Muske hlace\nDostupno u vise velicina.','https://deepview.news/img/products/64568-s-zelim-grad-sigurnosti-takticki-cargo-hlace-ljudi-swat-vojska-vojni-pantalone-covjece-opusteno-fleksibilan-multi-dzepu-pamuka-hlace.jpg',7,NULL,NULL,NULL),(30,'Haljina','50','Litter black dress.\nDostupno u vise boja','https://cdn.luxe.digital/media/2021/02/24170750/best-little-black-dresses-grace-karin-review-luxe-digital%402x.jpg',2,NULL,NULL,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_name`
--

DROP TABLE IF EXISTS `table_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `table_name` (
    `column_1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_name`
--

LOCK TABLES `table_name` WRITE;
/*!40000 ALTER TABLE `table_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `table_name` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-25 13:35:03
