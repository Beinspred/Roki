-- MySQL dump 10.13  Distrib 5.7.36, for Linux (x86_64)
--
-- Host: localhost    Database: roki
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `seo_slug` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (2,'Wommen',1,'wommen'),(3,'Man',3,'man'),(4,'Kids',4,'kids'),(5,'New Collection',2,'collection'),(11,'Seasonal',NULL,'seasonal');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` VALUES (11,'IMG_3720.JPG','image/jpeg','66266'),(12,'Specifikacija za Admin za APP sa orders deo.pdf','application/pdf','86480'),(13,'Untitled Diagram-2.drawio','application/octet-stream','2663'),(14,'obrazac+2.doc','application/msword','50688'),(15,'admin statistika .rtf','text/rtf','804');
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum_order` datetime DEFAULT CURRENT_TIMESTAMP,
  `ukupno` float DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `napomene` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,'2022-02-17 20:01:34',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(2,'2022-02-18 12:33:45',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(3,'2022-02-18 12:33:52',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(4,'2022-02-18 17:26:04',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(5,'2022-02-18 17:27:18',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(6,'2022-02-18 17:31:29',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(7,'2022-02-18 17:31:33',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(8,'2022-02-18 17:32:00',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(9,'2022-02-18 17:32:03',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(10,'2022-02-18 17:33:31',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(11,'2022-02-18 17:44:23',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(12,'2022-02-18 17:51:27',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(13,'2022-02-18 17:51:41',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(14,'2022-02-18 17:57:44',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(15,'2022-02-18 17:57:49',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(16,'2022-02-18 17:57:52',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(17,'2022-02-18 18:02:26',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(18,'2022-02-18 18:02:54',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(19,'2022-02-18 18:04:46',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(20,'2022-02-18 18:05:13',1050,'Nikola','nikola@gmail.com','1','bg','bg','1'),(21,'2022-02-18 18:06:20',1050,'Nikola','nikola@gmail.com','1','bg','bg','1');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `kolicina` int(11) DEFAULT NULL,
  `cijena` float DEFAULT NULL,
  `ukupno` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
INSERT INTO `order_item` VALUES (1,11,NULL,7,150,1050),(2,NULL,4,7,150,1050),(3,NULL,19,7,150,1050),(4,20,4,7,150,1050),(5,21,4,7,150,1050);
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime_proizvoda` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cijena` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opis_proizvoda` text COLLATE utf8mb4_unicode_ci,
  `slika` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visitor_counter` int(11) DEFAULT '0',
  `zalihe_robe` int(11) DEFAULT NULL,
  `kolicina` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `seo_slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (4,'Muska kosulja','150','Muska kosulja','',13,NULL,100,3,'kosulja'),(8,'Zenska kosulja','25','Zenska kosulja ','/image/images.jpeg',4,NULL,150,2,'hlace'),(22,'Duda','1','Duda za bebe','',0,NULL,1,1,'carape'),(32,'Duda','1','Duda za bebe','',0,NULL,1,3,'majica');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'aNikola',NULL,'nikola@gmail.com','1');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-22  1:22:29
